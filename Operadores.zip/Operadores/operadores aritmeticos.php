<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

echo (5 % 3)."\n";           // muestra 2
echo (5 % -3)."\n";          // muestra 2
echo (-5 % 3)."\n";          // muestra -2
echo (-5 % -3)."\n";         // muestra -2

?>
</body>
</html>