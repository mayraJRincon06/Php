<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

$a = ($b = 4) + 5; // ahora $a es igual a 9 y $b se ha establecido en 4.

?>
</body>
</html>