<DOCTYPE <!DOCTYPE html>
<html>
<head>
	<title>operadores para strings</title>
</head>
<body>
<?php
$a = "Hello ";
$b = $a . "World!"; // ahora $b contiene "Hello World!"

$a = "Hello ";
$a .= "World!";     // ahora $a contiene "Hello World!"
?>
</body>
</html>