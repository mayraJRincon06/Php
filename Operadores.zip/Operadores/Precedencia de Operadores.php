<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
echo 1+5*3;

echo(1+5)*3;
?>
</body>
</html>