<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php 

$a = 10;
$b = 8;


if ($a > $b) {
  echo "a es mayor que b";
} else {
  echo "a NO es mayor que b";
}



 ?>

</body>
</html>