<?php
include("b.php");
echo "a";
?>