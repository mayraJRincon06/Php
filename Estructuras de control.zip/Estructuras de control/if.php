<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php 

$a = 10;
$b = 6;


if ($a > $b) {
  echo "a es mayor que b";
  $b = $a;
}


 ?>

</body>
</html>