<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php


$a = 40;
$b = 40;

if ($a > $b) {
    echo "a es mayor que b";
} elseif ($a == $b) {
    echo "a es igual que b";
} else {
    echo "a es menor que b";
}


 ?>
</body>
</html>