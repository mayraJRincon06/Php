<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php
switch ($i=2) {
    case 0:
        echo "i es igual a 0";
        break;
    case 1:
        echo "i es igual a 1";
        break;
    case 2:
        echo "i es igual a 2";
        break;
    default:
       echo "i no es igual a 0, 1 ni 2";
}
?>
</body>
</html>