<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

$color = 'verde';
$fruta = 'manzana';

?>

test.php
<?php

echo "Una $fruta $color"; // Una

include 'vars.php';

echo "Una $fruta $color"; // Una manzana verde

?>
</body>
</html>