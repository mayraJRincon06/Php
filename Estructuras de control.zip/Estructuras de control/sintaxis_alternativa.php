<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php 

$a = 5;

if ($a == 5):
    echo "a igual 5";
    echo "...";
elseif ($a == 6):
    echo "a igual 6";
    echo "!!!";
else:
    echo "a no es 5 ni 6";
endif;


?>




 ?>

</body>
</html>